from django.contrib import admin

# Register your models here.
# username=veteran
# pass=Somling0411

from .models import SubmittedData



admin.site.register(SubmittedData)